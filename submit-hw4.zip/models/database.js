var keyvaluestore = require('../models/keyvaluestore.js');

var userKVS = new keyvaluestore('users');
userKVS.init(function(err, data) {
});

var restaurantKVS = new keyvaluestore('restaurants');
restaurantKVS.init(function(err, data) {
});

/* The function below is an example of a database method. Whenever you need to 
 access your database, you should define a function (myDB_addUser, myDB_getPassword, ...)
 and call that function from your routes - don't just call DynamoDB directly!
 This makes it much easier to make changes to your database schema. */


// NOT USED
var myDB_lookup = function(searchTerm, language, route_callbck) {
	console.log('Looking up: ' + searchTerm);
	kvs.get(searchTerm, function(err, data) {
		if (err) {
			route_callbck(null, "Lookup error: " + err);
		} else if (data === null) {
			route_callbck(null, null);
		} else {
			route_callbck({
				translation : data[0].value
			}, null);
		}
	});
};

//  SEARCH RESTAURANTS 
var myDB_restaurants = function(route_callbck) {
	// LOOK FOR RESTAURANTS
	restaurantKVS.scanKeys(function(err, data) {
		// ERROR
		if (data === null) {
			route_callbck(null, null);
		} else {
			route_callbck(null, data);
		}
	});
};

//SEARCH RESTAURANTS 
var myDB_restaurantInfo = function(restaurant, route_callbck) {
	// LOOK FOR RESTAURANTS
	restaurantKVS.get(restaurant, function(err, data) {
		// ERROR
		if (data === null) {
			route_callbck(null, null);
		} else {
			route_callbck(null, data);
		}
	});
};

var myDB_addUser = function(username, userpassword, userfullname, route_callbck) {
	// LOOK FOR RESTAURANTS
	var values = {
		password : userpassword,
		fullname : userfullname
	};
	userKVS.put(username, JSON.stringify(values), function(err, data) {
		// ERROR
		if (data === null) {
			route_callbck(null, null);
		} else {
			route_callbck(null, data);
		}
	});
};

var myDB_addRestaurant = function(restlat, restlong, restname, restdesc, restcreator, route_callbck) {
	var values = {
		latitude : restlat,
		longitude : restlong,
		desc : restdesc,
		creator : restcreator
	};
	restaurantKVS.put(restname, JSON.stringify(values), function(err, data) {
		if(data === null) {
			route_callbck(null, null);
		}
		else {
			route_callbck(null, data);
		}
	});
};

// USERS
var myDB_searchUser = function(username, password, route_callbck) {
	userKVS.exists(username, function(err, data) {
		if (err || data === null) {
			route_callbck(null, null);
		} 
		else {
			// CHECK PASSWORD
			userKVS.get(username, function(err, data) {
				if (err || data === null) {
					route_callbck(null, null);
				} else {
					var value = JSON.parse(data[0].value);
					// match
					if (value.password === password) {
						route_callbck(username, password);
					}
					// no match
					else {
						// NO MATCH
						route_callbck(null, null);
					}
				}
			});
		}
	});
};

/* We define an object with one field for each method. For instance, below we have
 a 'lookup' field, which is set to the myDB_lookup function. In routes.js, we can
 then invoke db.lookup(...), and that call will be routed to myDB_lookup(...). */

var database = {
	lookup : myDB_lookup,
	searchUser : myDB_searchUser,
	getRestaurants : myDB_restaurants,
	getRestaurantInfo : myDB_restaurantInfo,
	addUser : myDB_addUser,
	addRestaurant : myDB_addRestaurant
};

module.exports = database;
