var db = require('../models/database.js');

var async = require('async');

var getMain = function(req, res) {
	if (req.url === "/?message=no_match") {
		res.render('main.ejs', {
			message : "FORM NOT FILLED/USER DOESN'T EXIST/NO MATCH"
		});
	} else if (req.url === "/?message=not_signedin") {
		res.render('main.ejs', {
			message : "USER HAS NOT LOGGED IN/SIGNED UP!"
		});
	} else if (req.url === "/?message=user_exists") {
		res.render('main.ejs', {
			message : "USER ALREADY EXISTS!!"
		});
	} else {
		res.render('main.ejs', {
			message : null
		});
	}
};


var getSignUp = function(req, res) {
	res.render('signup.ejs', {});
};


var postResults = function(req, res) {
	var userInput = req.body.myInputField;
	db.lookup(userInput, "german", function(data, err) {
		if (err) {
			res.render('results.ejs', {
				theInput : userInput,
				message : err,
				result : null
			});
		} else if (data) {
			res.render('results.ejs', {
				theInput : userInput,
				message : null,
				result : data.translation
			});
		} else {
			res.render('results.ejs', {
				theInput : userInput,
				result : null,
				message : 'We did not find anything'
			});
		}
	});
};


var postLogin = function(req, res) {
	var userInput = req.body.myInputField;
	var userPassword = req.body.password;
	db.searchUser(userInput, userPassword, function(err, data) {
		if (data !== null && err !== null) {
			// SESSION OBJECT
			req.session.user = userInput;
			// MATCH LOOK FOR RESTAURANTS
			res.redirect("/restaurants");
		} else {
			// ERRORS
			// FLAG
			res.redirect("/?message=no_match");
		}
	});
};


var postSignup = function(req, res) {
	var userInput = req.body.myInputField;
	var userPassword = req.body.password;
	var fullname = req.body.fullname;
	db.addUser(userInput, userPassword, fullname, function(err, data) {
		if (data === null) {
			res.redirect("/?message=user_exists");
		} else {
			// SESSION OBJECT
			req.session.user = userInput;
			res.redirect("/restaurants");
		}
	});
};


var postAddRestaurants = function(req, res) {
	var latitude = req.body.latitude;
	var longitude = req.body.longitude;
	var name = req.body.name;
	var desc = req.body.description;
	var user = req.session.user;
	db.addRestaurant(latitude, longitude, name, desc, user, function(err, data) {
		// NO ERROR
		if (data !== null) {
			res.redirect("/restaurants");
		} 
	});
};


var getLogout = function(req, res) {
	// destroy session
	req.session.destroy();
	res.redirect("/");
};

var getRestaurants = function(req, res) {
	// USER HASN'T SIGNED IN
	if (req.session.user == null) {
		res.redirect("/?message=not_signedin");
	} else {
		var postNames = [];
		var postValues = [];
		db.getRestaurants(function(err, data) {
			postKeys = data;
			async.forEach(postKeys, function(post, route_callbck) {
				db.getRestaurantInfo(post.key, function(err, data) {
					postNames.push(post.key);
					if (data !== null) {
						var value = JSON.parse(data[0].value);
						postValues.push(value);
					}
					route_callbck();
				});

			}, function(err) {
				res.render('restaurants.ejs', {
					keys : postNames,
					values : postValues
				});
			});
		});
	}
};

var getRestData = function(req, res) {
	// USER HASN'T SIGNED IN
	if (req.session.user == null) {
		res.redirect("/?message=not_signedin");
	} else {
		var postNames = [];
		var postValues = [];
		db.getRestaurants(function(err, data) {
			postKeys = data;
			async.forEach(postKeys, function(post, route_callbck) {
				db.getRestaurantInfo(post.key, function(err, data) {
					postNames.push(post.key);
					if (data !== null) {
						var value = JSON.parse(data[0].value);
						postValues.push(value);
					}
					route_callbck();
				});

			}, function(err) {
				res.send({
					keys : postNames,
					values : postValues,
					user : req.session.user
				});
			});
		});
	}
};

var routes = {
	get_main : getMain,
	post_results : postResults,
	get_signup : getSignUp,
	post_login : postLogin,
	post_signup : postSignup,
	get_restaurants : getRestaurants,
	post_addrestaurants : postAddRestaurants,
	get_logout : getLogout,
	// MS2
	get_restdata : getRestData
};

module.exports = routes;
