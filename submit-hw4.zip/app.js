/* Some initialization boilerplate. Also, we include the code from
   routes/routes.js, so we can have access to the routes. Note that
   we get back the object that is defined at the end of routes.js,
   and that we use the fields of that object (e.g., routes.get_main)
   to access the routes. */

var express = require('express');
var routes = require('./routes/routes.js');
var app = express();

app.use(express.bodyParser());
app.use(express.logger("default"));
// SESSION
app.use(express.cookieParser());
app.use(express.session({secret: 'thisIsmySecret'}));


/* Below we install the routes. The first argument is the URL that we
   are routing, and the second argument is the handler function that
   should be invoked when someone opens that URL. Note the difference
   between app.get and app.post; normal web requests are GETs, but
   POST is often used when submitting web forms ('method="post"'). */

// login page
app.get('/', routes.get_main);

// signup page
app.get('/signup', routes.get_signup);

app.post('/createaccount', routes.post_signup);

// check login credentials
app.post('/checklogin', routes.post_login);

app.get('/logout', routes.get_logout);

//redirect
app.get('/restaurants', routes.get_restaurants);

app.post('/addrestaurant', routes.post_addrestaurants);

// MS2 RESTAURANT DATA FOR MARKERS
app.get('/restaurantdata', routes.get_restdata);


/* Run the server */

console.log('Author: Juan Padilla (juanpad)');
app.listen(8080);
console.log('Server running on port 8080. Now open http://localhost:8080/ in your browser!');
